<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package OAT_2017
 */
?>

<?php

$args = array(
        'post_type' => 'contact',
        'post_per_page' => -1,
        'orderby' => 'name',
        'order' => 'ASC'
        );
        $worklist = new WP_Query($args);

        if($worklist->have_posts()){
            echo "<h1>Contact</h1>";
            echo "<div class='contacts'>";
            while($worklist->have_posts()){
                $worklist->the_post();

			           if( have_rows('address')):

			           	while( have_rows('address')) : the_row();

			           the_sub_field('street_address');
			           the_sub_field('city');
			           the_sub_field('postal_code');
			           the_sub_field('phone_number');

			           endwhile;

			           else :
			           endif;
                echo get_field('email');
                echo "<div class='school_website'>";
                the_title();
                echo '<a href="';
                echo get_field('website_url');
                echo '">Website</a>';
                echo "</div>"; //End of school Website

                echo get_field('google_map');

            }
            echo "</div>";
            echo "<div class='clear'>";
            echo "</div>";
            wp_reset_postdata();
        }

$args = array(
        'post_type' => 'instructors',
        'post_per_page' => -1,
        'orderby' => 'name',
        'order' => 'ASC'
        );
        $worklist = new WP_Query($args);

        if($worklist->have_posts()){
            echo "<h1>Instructors</h1>";
            echo "<div class='contacts'>";
            while($worklist->have_posts()){
                $worklist->the_post();
                
                the_title();

		           if( have_rows('instructors')):

		           while( have_rows('instructors')) : the_row();

		           the_sub_field('job_title');
		           the_sub_field('phone_number');
		           the_sub_field('email');

		           endwhile;

		           else :
		           endif;

            }
            echo "</div>";
            echo "<div class='clear'>";
            echo "</div>";
            wp_reset_postdata();
        }
?>
