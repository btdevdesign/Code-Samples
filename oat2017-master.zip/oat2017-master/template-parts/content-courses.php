<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package OAT_2017
 */

?>

<?php 

$args = array(
		'post_type' => 'course',
		'post_per_page' => -1,
		'orderby' => 'name',
		'order' => 'ASC'
		);
		$worklist = new WP_Query($args);

		if($worklist->have_posts()){
			echo "<h1>Courses:</h1>";
			echo "<div class='course-list'>";
			while($worklist->have_posts()){
				$worklist->the_post();

				echo "<div class='individual-course'>";
				the_title();
				the_content();
				echo get_field('credits');
				echo '<a href="';
				echo get_field('pdf_link');
				echo '">PDF LINK</a>';
				echo "</div>"; //End of individual course div
			}
			echo "</div>";
			echo "<div class='clear'>";
			echo "</div>";
			wp_reset_postdata();
		}

?>