<?php
/**
 * OAT2017 functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package OAT2017
 */

if ( ! function_exists( 'oat_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function oat_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on OAT2017, use a find and replace
	 * to change 'oat' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'oat', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
    add_image_size( 'course-pdf', 50, 50, true );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'menu-1' => esc_html__( 'Primary', 'oat' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'oat_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'oat_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function oat_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'oat_content_width', 640 );
}
add_action( 'after_setup_theme', 'oat_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function oat_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'oat' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'oat' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'oat_widgets_init' );


//CUSTOM POST TYPES

function oat_register_custom_post_types() {

	//STUDENT CUSTOM POST TYPE

    $labels = array(
        'name'               => _x( 'Students', 'post type general name' ),
        'singular_name'      => _x( 'Student', 'post type singular name'),
        'menu_name'          => _x( 'Students', 'admin menu' ),
        'name_admin_bar'     => _x( 'Student', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'student' ),
        'add_new_item'       => __( 'Add New student' ),
        'new_item'           => __( 'New Student' ),
        'edit_item'          => __( 'Edit Student' ),
        'view_item'          => __( 'View Student' ),
        'all_items'          => __( 'All Students' ),
        'search_items'       => __( 'Search Students' ),
        'parent_item_colon'  => __( 'Parent Students:' ),
        'not_found'          => __( 'No students found.' ),
        'not_found_in_trash' => __( 'No students found in Trash.' ),
        'archives'           => __( 'Student Archives'),
        'insert_into_item'   => __( 'Uploaded to this student'),
        'uploaded_to_this_item' => __( 'Student Archives'),
        'filter_item_list'   => __( 'Filter students list'),
        'items_list_navigation' => __( 'Students list navigation'),
        'items_list'         => __( 'Students list'),
        'featured_image'     => __( 'Student feature image'),
        'set_featured_image' => __( 'Set student feature image'),
        'remove_featured_image' => __( 'Remove student feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'students_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-id-alt',
    );
    register_post_type( 'student', $args );


    //COURSES CUSTOM POST TYPE

    $labels = array(
        'name'               => _x( 'Courses', 'post type general name' ),
        'singular_name'      => _x( 'Course', 'post type singular name'),
        'menu_name'          => _x( 'Courses', 'admin menu' ),
        'name_admin_bar'     => _x( 'Course', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'course' ),
        'add_new_item'       => __( 'Add New course' ),
        'new_item'           => __( 'New Course' ),
        'edit_item'          => __( 'Edit Course' ),
        'view_item'          => __( 'View Course' ),
        'all_items'          => __( 'All Courses' ),
        'search_items'       => __( 'Search Courses' ),
        'parent_item_colon'  => __( 'Parent Courses:' ),
        'not_found'          => __( 'No courses found.' ),
        'not_found_in_trash' => __( 'No courses found in Trash.' ),
        'archives'           => __( 'Course Archives'),
        'insert_into_item'   => __( 'Uploaded to this course'),
        'uploaded_to_this_item' => __( 'Course Archives'),
        'filter_item_list'   => __( 'Filter courses list'),
        'items_list_navigation' => __( 'Courses list navigation'),
        'items_list'         => __( 'Courses list'),
        'featured_image'     => __( 'Course feature image'),
        'set_featured_image' => __( 'Set course feature image'),
        'remove_featured_image' => __( 'Remove course feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'courses_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-book-alt',
    );
    register_post_type( 'course', $args );


    //CERTIFICATE CUSTOM POST TYPE

    $labels = array(
        'name'               => _x( 'Certificates', 'post type general name' ),
        'singular_name'      => _x( 'Certificate', 'post type singular name'),
        'menu_name'          => _x( 'Certificate', 'admin menu' ),
        'name_admin_bar'     => _x( 'Certificate', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'certificate' ),
        'add_new_item'       => __( 'Add New certificate' ),
        'new_item'           => __( 'New Certificate' ),
        'edit_item'          => __( 'Edit Certificate' ),
        'view_item'          => __( 'View Certificate' ),
        'all_items'          => __( 'All Certificates' ),
        'search_items'       => __( 'Search Certificates' ),
        'parent_item_colon'  => __( 'Parent Certificates:' ),
        'not_found'          => __( 'No certificates found.' ),
        'not_found_in_trash' => __( 'No certificates found in Trash.' ),
        'archives'           => __( 'Certificate Archives'),
        'insert_into_item'   => __( 'Uploaded to this certificate'),
        'uploaded_to_this_item' => __( 'Certificate Archives'),
        'filter_item_list'   => __( 'Filter certificates list'),
        'items_list_navigation' => __( 'Certificates list navigation'),
        'items_list'         => __( 'Certificates list'),
        'featured_image'     => __( 'Certificate feature image'),
        'set_featured_image' => __( 'Set certificate feature image'),
        'remove_featured_image' => __( 'Remove certificate feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'certificates_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-awards',
    );
    register_post_type( 'certificate', $args );


    	// CONTACT CUSTOM POST TYPE

        $labels = array(
        'name'               => _x( 'Contacts', 'post type general name' ),
        'singular_name'      => _x( 'Contact', 'post type singular name'),
        'menu_name'          => _x( 'Contact', 'admin menu' ),
        'name_admin_bar'     => _x( 'Contact', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'contact' ),
        'add_new_item'       => __( 'Add New contact' ),
        'new_item'           => __( 'New Contacts' ),
        'edit_item'          => __( 'Edit Contacts' ),
        'view_item'          => __( 'View Contacts' ),
        'all_items'          => __( 'All Contacts' ),
        'search_items'       => __( 'Search Contacts' ),
        'parent_item_colon'  => __( 'Parent Contacts:' ),
        'not_found'          => __( 'No contacts found.' ),
        'not_found_in_trash' => __( 'No contacts found in Trash.' ),
        'archives'           => __( 'Contact Archives'),
        'insert_into_item'   => __( 'Uploaded to this contact'),
        'uploaded_to_this_item' => __( 'Contact Archives'),
        'filter_item_list'   => __( 'Filter contacts list'),
        'items_list_navigation' => __( 'Contacts list navigation'),
        'items_list'         => __( 'Contacts list'),
        'featured_image'     => __( 'Contact feature image'),
        'set_featured_image' => __( 'Set contact feature image'),
        'remove_featured_image' => __( 'Remove contact feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'contacts_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-phone',
    );
    register_post_type( 'contact', $args );


        // JOB LINKS CUSTOM POST TYPE

        $labels = array(
        'name'               => _x( 'Job Links', 'post type general name' ),
        'singular_name'      => _x( 'Job Link', 'post type singular name'),
        'menu_name'          => _x( 'Job Link', 'admin menu' ),
        'name_admin_bar'     => _x( 'Job Link', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'job link' ),
        'add_new_item'       => __( 'Add New job link' ),
        'new_item'           => __( 'New Job Links' ),
        'edit_item'          => __( 'Edit Job Links' ),
        'view_item'          => __( 'View Job Links' ),
        'all_items'          => __( 'All Job Links' ),
        'search_items'       => __( 'Search Job Links' ),
        'parent_item_colon'  => __( 'Parent Job Links:' ),
        'not_found'          => __( 'No job links found.' ),
        'not_found_in_trash' => __( 'No job links found in Trash.' ),
        'archives'           => __( 'Job link Archives'),
        'insert_into_item'   => __( 'Uploaded to this job link'),
        'uploaded_to_this_item' => __( 'Job Link Archives'),
        'filter_item_list'   => __( 'Filter job links list'),
        'items_list_navigation' => __( 'Job Links list navigation'),
        'items_list'         => __( 'Job Links list'),
        'featured_image'     => __( 'Job link feature image'),
        'set_featured_image' => __( 'Set job link feature image'),
        'remove_featured_image' => __( 'Remove job link feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'job_links_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-editor-justify',
    );
    register_post_type( 'job_links', $args );



        // INSTRUCTORS CUSTOM POST TYPE

        $labels = array(
        'name'               => _x( 'Instructors', 'post type general name' ),
        'singular_name'      => _x( 'Instructor', 'post type singular name'),
        'menu_name'          => _x( 'Instructor', 'admin menu' ),
        'name_admin_bar'     => _x( 'Instructor', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'instructor' ),
        'add_new_item'       => __( 'Add New instructor' ),
        'new_item'           => __( 'New Instructors' ),
        'edit_item'          => __( 'Edit Instructors' ),
        'view_item'          => __( 'View Instructors' ),
        'all_items'          => __( 'All Instructors' ),
        'search_items'       => __( 'Search Instructors' ),
        'parent_item_colon'  => __( 'Parent Instructors:' ),
        'not_found'          => __( 'No instructors found.' ),
        'not_found_in_trash' => __( 'No instructors found in Trash.' ),
        'archives'           => __( 'Instructor Archives'),
        'insert_into_item'   => __( 'Uploaded to this instructor'),
        'uploaded_to_this_item' => __( 'Instructor Archives'),
        'filter_item_list'   => __( 'Filter instructors list'),
        'items_list_navigation' => __( 'Instructors list navigation'),
        'items_list'         => __( 'Instructors list'),
        'featured_image'     => __( 'Instructor feature image'),
        'set_featured_image' => __( 'Set instructor feature image'),
        'remove_featured_image' => __( 'Remove instructor feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'instructors_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-id',
    );
    register_post_type( 'instructors', $args );


        // FOOTERS CUSTOM POST TYPE

        $labels = array(
        'name'               => _x( 'Footer Links', 'post type general name' ),
        'singular_name'      => _x( 'Footer Link', 'post type singular name'),
        'menu_name'          => _x( 'Footer Link', 'admin menu' ),
        'name_admin_bar'     => _x( 'Footer Link', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'footer link' ),
        'add_new_item'       => __( 'Add New footer link' ),
        'new_item'           => __( 'New Footer Links' ),
        'edit_item'          => __( 'Edit Footer Links' ),
        'view_item'          => __( 'View Footer Links' ),
        'all_items'          => __( 'All Footer Links' ),
        'search_items'       => __( 'Search Footer Links' ),
        'parent_item_colon'  => __( 'Parent Footer Links:' ),
        'not_found'          => __( 'No footer links found.' ),
        'not_found_in_trash' => __( 'No footer links found in Trash.' ),
        'archives'           => __( 'Footer Link Archives'),
        'insert_into_item'   => __( 'Uploaded to this footer link'),
        'uploaded_to_this_item' => __( 'Footer Link Archives'),
        'filter_item_list'   => __( 'Filter footer links list'),
        'items_list_navigation' => __( 'Footer Links list navigation'),
        'items_list'         => __( 'Footer Links list'),
        'featured_image'     => __( 'Footer Link feature image'),
        'set_featured_image' => __( 'Set footer link feature image'),
        'remove_featured_image' => __( 'Remove footer link feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'footer_links_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-universal-access',
    );
    register_post_type( 'footer_links', $args );

        // FOOTERS CUSTOM POST TYPE

        $labels = array(
        'name'               => _x( 'Schedule', 'post type general name' ),
        'singular_name'      => _x( 'Schedule', 'post type singular name'),
        'menu_name'          => _x( 'Schedule', 'admin menu' ),
        'name_admin_bar'     => _x( 'Schedule', 'add new on admin bar' ),
        'add_new'            => _x( 'Add New', 'schedule' ),
        'add_new_item'       => __( 'Add New schedule' ),
        'new_item'           => __( 'New Schedule' ),
        'edit_item'          => __( 'Edit Schedule' ),
        'view_item'          => __( 'View Schedule' ),
        'all_items'          => __( 'All Schedule' ),
        'search_items'       => __( 'Search Schedule' ),
        'parent_item_colon'  => __( 'Parent Schedule:' ),
        'not_found'          => __( 'No schedule found.' ),
        'not_found_in_trash' => __( 'No schedule found in Trash.' ),
        'archives'           => __( 'Schedule Archives'),
        'insert_into_item'   => __( 'Uploaded to this schedule'),
        'uploaded_to_this_item' => __( 'Schedule Archives'),
        'filter_item_list'   => __( 'Filter schedule list'),
        'items_list_navigation' => __( 'schedule list navigation'),
        'items_list'         => __( 'Schedule list'),
        'featured_image'     => __( 'Schedule feature image'),
        'set_featured_image' => __( 'Set schedule feature image'),
        'remove_featured_image' => __( 'Remove schedule feature image'),
        'use_featured_image' => __( 'Use as feature image'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => true,
        'show_in_admin_bar'  => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'schedule_cpt' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-list-view',
    );
    register_post_type( 'schedule', $args );


 }
 add_action( 'init', 'oat_register_custom_post_types' );


/*********************************************************
****************TAXONOMIES********************************
*********************************************************/

/*Job Sites taxonimies */
 function oat_register_taxonomies() {
    $labels = array(
        'name'              => _x( 'Jobs', 'taxonomy general name' ),
        'singular_name'     => _x( 'Job', 'taxonomy singular name' ),
        'search_items'      => __( 'Search Jobs' ),
        'all_items'         => __( 'All Job Types' ),
        'parent_item'       => __( 'Parent Job Category' ),
        'parent_item_colon' => __( 'Parent Job Category:' ),
        'edit_item'         => __( 'Edit Job Category' ),
        'view_item'         => __( 'View Job Category' ),
        'update_item'       => __( 'Update Job Category' ),
        'add_new_item'      => __( 'Add New Job Category' ),
        'new_item_name'     => __( 'New Job Category Name' ),
        'menu_name'         => __( 'Job Category' ),
    );
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_in_nav_menu'  => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'job-categories' ),
    );
    register_taxonomy( 'job-category', array( 'job_links' ), $args );

/*Footer Link Taxonimies */
    $labels = array(
        'name'              => _x( 'Footer Links', 'taxonomy general name' ),
        'singular_name'     => _x( 'Footer Link', 'taxonomy singular name' ),
        'search_items'      => __( 'Search Footer Links' ),
        'all_items'         => __( 'All Footer Link Types' ),
        'parent_item'       => __( 'Parent Footer Link Category' ),
        'parent_item_colon' => __( 'Parent Footer Link Category:' ),
        'edit_item'         => __( 'Edit Footer Link Category' ),
        'view_item'         => __( 'Vview Footer Link Category' ),
        'update_item'       => __( 'Update Footer Link Category' ),
        'add_new_item'      => __( 'Add New Footer Link Category' ),
        'new_item_name'     => __( 'New Footer Link Category Name' ),
        'menu_name'         => __( 'Footer Link Category' ),
    );
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_in_nav_menu'  => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'footer-link-categories' ),
    );
    register_taxonomy( 'footer-link-category', array( 'footer_links' ), $args );
 }
 add_action( 'init', 'oat_register_taxonomies');




/**
 * Enqueue scripts and styles.
 */
function oat_scripts() {
	wp_enqueue_style( 'oat-style', get_stylesheet_uri() );

	wp_enqueue_script( 'oat-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'oat-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'oat_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';
