<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OAT_2017
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">

			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'oat2017' ) ); ?>"><?php printf( esc_html__( 'Proudly powered by %s', 'oat2017' ), 'WordPress' ); ?></a>

<?php
  $args = array (
      'post_type' =>'footer_links',
      'posts_per_page' => -1,
      'tax_query' => array(
        array(
          'taxonomy' => 'footer-link-category',
          'field' => 'slug',
          'terms' => 'for_student_tax',
          )
        )   
  );  
  $worklist= new WP_Query($args);
  
        if($worklist->have_posts()){
            echo "<div class='footer_links'>";
            while($worklist->have_posts()){
                $worklist->the_post();
                echo "<h3>For Students</h3>";
                echo "<div class='individual_footer_links'>";
                if(have_rows('footer_links'));
                echo '<ul>';
                    while(have_rows('footer_links')) : the_row();
                    echo '<li><a href="';
                    echo the_sub_field('footer_url');
                    echo '">';
                    echo the_sub_field('footer_link_name');
                    echo '</a></li>';
                    endwhile;
                    
                echo '</ul>';
                echo "</div>"; //End of individual course div
            }
            echo "</div>";
            echo "<div class='clear'>";
            echo "</div>";
            wp_reset_postdata();
        }
  
   $args = array (
      'post_type' =>'footer_links',
      'posts_per_page' => -1,
      'tax_query' => array(
        array(
          'taxonomy' => 'footer-link-category',
          'field' => 'slug',
          'terms' => 'program_links_tax',
          )
        )   
  );  
  $worklist= new WP_Query($args);
  
        if($worklist->have_posts()){
            echo "<div class='footer_links'>";
            while($worklist->have_posts()){
                $worklist->the_post();
                echo "<h3>For Program</h3>";
                echo "<div class='individual_footer_links'>";
                if(have_rows('footer_links'));
                echo '<ul>';
                    while(have_rows('footer_links')) : the_row();
                    echo '<li><a href="';
                    echo the_sub_field('footer_url');
                    echo '">';
                    echo the_sub_field('footer_link_name');
                    echo '</a></li>';
                    endwhile;
                    
                echo '</ul>';
                echo "</div>"; //End of individual course div
            }
            echo "</div>";
            echo "<div class='clear'>";
            echo "</div>";
            wp_reset_postdata();
        }
  
?>

			<span class="sep"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'oat2017' ), 'oat2017', '<a href="https://automattic.com/" rel="designer">Brian, Brianna, Chris, Ivan</a>' ); ?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
